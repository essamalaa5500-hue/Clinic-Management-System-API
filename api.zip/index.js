const express = require("express");
const app = express();
const cookieParser = require("cookie-parser");
require("dotenv").config();
require("./config/db");
const PORT = process.env.PORT || 6000;
const usersRouter = require("./src/routes/users");
const authRouter = require("./src/routes/auth");
const patientRouter = require("./src/routes/patient");
const specializationRouter = require("./src/routes/specialization");
const doctorRouter = require("./src/routes/doctor");
const appointmentRouter = require("./src/routes/appointment");
const dashboardRouter = require("./src/routes/dashboard");
const expenseRouter = require("./src/routes/expense");
const swaggerDocs = require("./docs/swagger");

app.use(express.json());
app.use(cookieParser());
app.use(express.urlencoded({ extended: true }));

app.get("/", (req, res) => {
  res.send("Hello World!");
});

//routes
app.use("/users", usersRouter);
app.use("/auth", authRouter);
app.use("/patient", patientRouter);
app.use("/specialization", specializationRouter);
app.use("/doctor", doctorRouter);
app.use("/appointment", appointmentRouter);
app.use("/dashboard", dashboardRouter);
app.use("/expense", expenseRouter);

// Global Error Handler
app.use((err, req, res, next) => {
  console.error(err);

  res.status(err.statusCode || 500).json({
    status: err.statusCode || 500,
    message: err.message || "Internal Server Error",
    error: err.errors || null,
  });
});
// Start Server
app.listen(PORT, () => {
  console.log(` Server is running on port ${PORT}`);
});
