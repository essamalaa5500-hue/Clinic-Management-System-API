const express = require("express");
const router = express.Router();

const {
  createAppointmentValidation,
  updateAppointmentValidation,
  updateAppointmentStatusValidation,
  getAppointmentsValidation,
} = require("../../middlewares/appointment");

const  validateObjectId  = require("../../middlewares/validateObjectId");
const paginate = require("../../middlewares/paginate");
const { verifyToken } = require("../../middlewares/verifyToken");
const { verifyAdmin } = require("../../middlewares/verifyAdmin");

const {
  createAppointment,
  getAppointmentById,
  updateAppointment,
  updateAppointmentStatus,
  getAppointmentsByDoctor,
  getAppointmentsByPatient,
  getTodaysAppointments,
  getAppointments,
  getAllAppointments,
  deleteAppointment,
} = require("../controllers/appointmentController");

// ========================= Create =========================

router.post(
  "/",
  verifyToken,
  verifyAdmin,
  createAppointmentValidation,
  createAppointment,
);

// ========================= Read =========================

// All appointments with filters, sorting & pagination
router.get(
  "/",
  verifyToken,
  verifyAdmin,
  getAppointmentsValidation,
  paginate,
  getAppointments,
);

// Optional: Get all appointments without filters
router.get("/all", verifyToken, verifyAdmin, getAllAppointments);

// Today's appointments
router.get("/today", verifyToken, verifyAdmin, paginate, getTodaysAppointments);

// Appointments by doctor
router.get(
  "/doctor/:id",
  verifyToken,
  verifyAdmin,
  validateObjectId,
  paginate,
  getAppointmentsByDoctor,
);

// Appointments by patient
router.get(
  "/patient/:id",
  verifyToken,
  verifyAdmin,
  validateObjectId,
  paginate,
  getAppointmentsByPatient,
);

// Get appointment by id
router.get(
  "/:id",
  verifyToken,
  verifyAdmin,
  validateObjectId,
  getAppointmentById,
);

// ========================= Update =========================

// Update appointment
router.patch(
  "/:id",
  verifyToken,
  verifyAdmin,
  validateObjectId,
  updateAppointmentValidation,
  updateAppointment,
);

// Update appointment status
router.patch(
  "/:id/status",
  verifyToken,
  verifyAdmin,
  validateObjectId,
  updateAppointmentStatusValidation,
  updateAppointmentStatus,
);

// ========================= Delete =========================

router.delete(
  "/:id",
  verifyToken,
  verifyAdmin,
  validateObjectId,
  deleteAppointment,
);

module.exports = router;
